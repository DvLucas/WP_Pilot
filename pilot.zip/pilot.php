<?php
/*
Plugin Name: Leads Pilot Solution
Description: Envia los datos de formularios de WPForms como leads a Pilot Solution
Version: 1.0
Author: Lucas Benitez
*/
/*
Formularios:
Quiero Ser Cliente - ID: 1906
Soy Cliente - ID: 1919
Quiero Contactarme con Ustedes - ID:1926 
Whatsapp - ID: 1897
*/
add_action( 'wp_ajax_wpforms_submit', 'tu_funcion' );
add_action( 'wp_ajax_nopriv_wpforms_submit', 'tu_funcion' );

function tu_funcion() {
    $id = $_POST['wpforms']['id'];
    $fields = $_POST['wpforms']['fields'];

    // Variables de configuración
    $serviceURL = "https://api.pilotsolution.net/webhooks/welcome.php";
    $appKey = "4A2A14E8-8628-430B-B174-336A154D709F"; 
    $tipoNegocio = "1";  
    $origendeldato = "F7YYV509LL0EPPZB5"; 
    $landing_link = "https://marquezyasociados.com.ar/contacto/"; 
    
    // Parámetros que pueden venir de un formulario
    $params = array(
        'action' => 'create',
        'appkey' => $appKey,
        'pilot_contact_type_id' => '1', // electrónico
        'pilot_business_type_id' => $tipoNegocio,
        'pilot_suborigin_id' => $origendeldato,
        'pilot_provider_url' => $landing_link
        // 'pilot_firstname' => sanitize_text_field($fields['1']),
        // 'pilot_cellphone' => sanitize_text_field($fields['2']),
        //'pilot_email' => sanitize_text_field($_POST['wpforms']['fields']['email']),
        //'pilot_notes' => sanitize_text_field($_POST['wpforms']['fields']['comentarios']),
    );

    if ($id === '1906' || $id === '1926')
    {
        $params['pilot_firstname'] = sanitize_text_field($fields['1']);
        $params['pilot_email'] = sanitize_text_field($fields['2']);
        $params['pilot_cellphone'] = sanitize_text_field($fields['3']);
        $params['pilot_notes'] = sanitize_text_field($fields['4']);
    }
    if ($id === '1919')
    {
        $params['pilot_firstname'] = sanitize_text_field($fields['1']);
        $params['pilot_email'] = sanitize_text_field($fields['2']);
        $params['pilot_cellphone'] = sanitize_text_field($fields['3']);
        $params['pilot_notes'] = sanitize_text_field('Area: ' + $fields['4'] + '- Consulta: ' + $fields['5']);
        $params['pilot_province'] = sanitize_text_field($fields['6']);
    }
    if ('1897')
    {
        $params['pilot_firstname'] = sanitize_text_field($fields['1']);
        $params['pilot_cellphone'] = sanitize_text_field($fields['2']);
    }
    // Envía la solicitud al servicio web utilizando wp_remote_post()
    $response = wp_remote_post($serviceURL, array(
        'body' => $params,
        'timeout' => 30,
        'sslverify' => false // desactivar la verificación SSL si es necesario
    ));
    
    // Verifica si la solicitud se realizó correctamente
    if (is_wp_error($response)) {
        wp_send_json_error( "Error al enviar la solicitud. Por favor, inténtalo de nuevo más tarde." );
    } else {
        $response_body = wp_remote_retrieve_body($response);
        wp_send_json_success( $response_body );
    }
    
    die();
}